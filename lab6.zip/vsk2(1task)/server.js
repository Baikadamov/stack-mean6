const express = require("express");
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const User = require("./userModel");
var cors = require("cors");
const Item = require("./itemModel");
const multer = require("multer");
const upload = multer({ dest: "uploads/" });
const app = new express();
const swaggerJSDoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");
app.use(cors());

const options = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "Node js Api",
      version: "1.0.0",
    },
    servers: [
      {
        url: "http://localhost:3000/",
      },
    ],
  },
  apis: ["./server.js"],
};

const swaggerSpec = swaggerJSDoc(options);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

/**
 * @swagger
 * /:
 *   get:
 *      summary: This api is used to check if get method is working or not
 *      description: This api is used to check if get method is working or not
 *      responses:
 *          200:
 *              description: To test get method
 */
app.get('/', (req, res) => {
  res.send("Hello Api");
});


app.listen(3000, () => {
  console.log("node api run on port 3000");
});

//Подключние к базе данных
mongoose
  .connect("mongodb://0.0.0.0:27017/users")
  .then(() => {
    console.log("connected to mongo");
  })
  .catch((error) => {
    console.log(error);
  });

app.use(express.json());


/**
 * @swagger
 * /login:
 *   post:
 *      summary: This API is used to log in by email and password
 *      description: This API is used to log in by email and password
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                email:
 *                  type: string
 *                  example: user@example.com
 *                password:
 *                  type: string
 *                  example: password123
 *      responses:
 *          200:
 *              description: Successful login
 *              content:
 *                application/json:
 *                  schema:
 *                    type: object
 *                    properties:
 *                      success:
 *                        type: boolean
 *                        example: true
 *                      data:
 *                        type: object
 *                        properties:
 *                          userId:
 *                            type: string
 *                            example: "123456"
 *                          email:
 *                            type: string
 *                            example: user@example.com
 *                          token:
 *                            type: string
 *                            example: "your_jwt_token_here"
 */
app.post("/login", async (req, res, next) => {
  let { email, password } = req.body;

  let existingUser;
  try {
    existingUser = await User.findOne({ email: email });
  } catch {
    const error = new Error("Error! Something went wrong.");
    return next(error);
  }
  if (!existingUser || existingUser.password != password) {
    const error = Error("Wrong check inputs again");
    return next(error);
  }
  let token;
  try {
    token = jwt.sign(
      { userId: existingUser.id, email: existingUser.email },
      "secretkeyappearshere",
      { expiresIn: "1h" }
    );
  } catch (err) {
    console.log(err);
    const error = new Error("Error! Something went wrong.");
    return next(error);
  }

  res.status(200).json({
    success: true,
    data: {
      userId: existingUser.id,
      email: existingUser.email,
      token: token,
    },
  });
});


/**
 * @swagger
 * /signup:
 *   post:
 *      summary: This API is used to sign up with a new user account
 *      description: This API is used to sign up with a new user account
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                name:
 *                  type: string
 *                  example: John Doe
 *                email:
 *                  type: string
 *                  example: user@example.com
 *                password:
 *                  type: string
 *                  example: password123
 *      responses:
 *          201:
 *              description: User successfully signed up
 *              content:
 *                application/json:
 *                  schema:
 *                    type: object
 *                    properties:
 *                      success:
 *                        type: boolean
 *                        example: true
 *                      data:
 *                        type: object
 *                        properties:
 *                          userId:
 *                            type: string
 *                            example: "123456"
 *                          email:
 *                            type: string
 *                            example: user@example.com
 *                          token:
 *                            type: string
 *                            example: "your_jwt_token_here"
 */
app.post("/signup", async (req, res, next) => {
  const { name, email, password } = req.body;

  let existingUser;
  try {
    existingUser = await User.findOne({ email: email });
  } catch (err) {
    const error = new Error("Error! Something went wrong.");
    return next(error);
  }

  if (existingUser) {
    const error = new Error("User with this email already exists.");
    return next(error);
  }

  const newUser = User({
    name,
    email,
    password,
  });

  try {
    await newUser.save();
  } catch {
    const error = new Error("Error! Something went wrong.");
    return next(error);
  }
  let token;
  try {
    token = jwt.sign(
      { userId: newUser.id, email: newUser.email },
      "secretkeyappearshere",
      { expiresIn: "1h" }
    );
  } catch (err) {
    const error = new Error("Error! Something went wrong.");
    return next(error);
  }
  res.status(201).json({
    success: true,
    data: { userId: newUser.id, email: newUser.email, token: token },
  });
});

app.get("/accessResource", (req, res) => {
  const token = req.headers.authorization.split(" ")[1];
  if (!token) {
    res
      .status(200)
      .json({ success: false, message: "Error! Token was not provided." });
  }
  const decodedToken = jwt.verify(token, "secretkeyappearshere");
  res.status(200).json({
    success: true,
    data: { userId: decodedToken.userId, email: decodedToken.email },
  });
});

app.post("/item-create", async (req, res) => {
  if (!req.headers.authorization) {
    return res.status(401).json({ error: "Unauthorized - Token is missing" });
  }

  const token = req.headers.authorization.split(" ")[1];

  if (!token) {
    return res.status(401).json({ error: "Unauthorized - Token is missing" });
  }

  try {
    const decodedToken = jwt.verify(token, "secretkeyappearshere");

    const new_item = await Item.findOne({ name: req.body.name });
    if (!new_item) {
      await Item.create({
        name: req.body.name,
        price: req.body.price,
        year: req.body.year,
      }).then(() => {
        res.send({ message: "Success" });
      });
    } else {
      res.status(400).send({ error: "Name is already in use!" });
    }
  } catch (error) {
    console.error(error);
    res.status(401).send({ error: "Unauthorized - Invalid Token" });
  }
});

app.put("/item-update", async (req, res) => {
  if (!req.headers.authorization) {
    return res.status(401).json({ error: "Unauthorized - Token is missing" });
  }

  const token = req.headers.authorization.split(" ")[1];

  if (!token) {
    return res.status(401).json({ error: "Unauthorized - Token is missing" });
  }

  try {
    const decodedToken = jwt.verify(token, "secretkeyappearshere");

    const new_item = await Item.findOne({ name: req.body.name });
    if (new_item != null) {
      await new_item
        .updateOne({
          name: req.body.name,
          price: req.body.price,
          year: req.body.year,
        })
        .then(() => {
          res.send({ message: "success" });
        });
    } else {
      res.status(404).send({ error: "error something went wrong" });
    }
  } catch (error) {
    throw error;
  }
});

app.delete("/item-delete", async (req, res) => {
  if (!req.headers.authorization) {
    return res.status(401).json({ error: "Unauthorized - Token is missing" });
  }

  const token = req.headers.authorization.split(" ")[1];

  if (!token) {
    return res.status(401).json({ error: "Unauthorized - Token is missing" });
  }

  try {
    const new_item = await Item.findOne({ name: req.body.name });
    if (new_item == null) {
      res.json({ message: "Item not found" });
    } else {
      await new_item.deleteOne().then((err) => {
        if (err != null) {
          res.send(err);
        } else {
          res.json({ message: "Item is deleted successfully" });
        }
      });
    }
  } catch {
    throw error;
  }
});

app.get("/items", async (req, res) => {
  try {
    if (!req.headers.authorization) {
      return res.status(401).json({ error: "Unauthorized - Token is missing" });
    }

    const token = req.headers.authorization.split(" ")[1];

    if (!token) {
      return res.status(401).json({ error: "Unauthorized - Token is missing" });
    }

    const items = await Item.find({});

    if (!items || items.length === 0) {
      return res.status(404).json({ error: "Items not found" });
    }

    const decodedToken = jwt.verify(token, "secretkeyappearshere");

    res.json(items);
  } catch (error) {
    if (error.name === "JsonWebTokenError") {
      return res.status(401).json({ error: "Unauthorized - Invalid token" });
    } else if (error.name === "TokenExpiredError") {
      return res
        .status(401)
        .json({ error: "Unauthorized - Token has expired" });
    } else {
      console.error(error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  }
});
